#include <gtest/gtest.h>

TEST(NotSimpleTest, TestOnePlusOne) {
    ASSERT_EQ(1 + 1, 2);
}
